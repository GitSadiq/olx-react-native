import Navigate from "./src/nevigation"


export default function App() {
  return <Navigate/>
}
